All the libraries are used for this project are present here in ".zip"
Download them raw and directly upload it in your IDE to compile your sketch without errors.